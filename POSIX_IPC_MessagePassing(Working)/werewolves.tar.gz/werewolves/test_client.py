from mpi4py import MPI

def receive_message():
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    if(rank==0):
        print('Hello from ' + str(rank))
    elif(rank==1):
        print('Hello from '  + str(rank))
    elif(rank==2):
        print('Hello from '  + str(rank))
    elif(rank==3):
        print('Hello from '  + str(rank))

if __name__ == "__main__":
    MPI.COMM_WORLD.Barrier()
    receive_message()
